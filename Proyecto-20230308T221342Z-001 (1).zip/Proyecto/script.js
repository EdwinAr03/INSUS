function mostramela(){

    horaactual = new Date();
    hora = horaactual.getHours();
    minuto = horaactual.getMinutes();
    segundo = horaactual.getSeconds();

    horaImprimir = hora + ":" + minuto + ":" + segundo;

    document.getElementById('hora').innerHTML = horaImprimir;

}
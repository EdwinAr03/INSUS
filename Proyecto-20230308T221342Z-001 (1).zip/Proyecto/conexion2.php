<?php
    include_once('db.php');
    ini_set('date.timezone', 'America/Bogota');
    $t = date("g:i a", strtotime(date('H:i:s',time()+00300)));
    $documento = $_POST['documento'];
    $nombres = $_POST['nombres'];
    $apellidos = $_POST['apellidos'];
    $departamento = $_POST['departamento'];

    $conectar=conn();
    $sql = "INSERT INTO `salida` (`documento`, `nombres`, `apellidos`, `departamento`,`hora`)
     VALUES ('$documento', '$nombres', '$apellidos', '$departamento', '$t')";
    $resul = mysqli_query($conectar, $sql) or trigger_error("Query failed! SQL- Error:".mysqli_error($conectar), E_USER_ERROR);

    echo '<script>alert("Registro exitoso")</script>';
?>
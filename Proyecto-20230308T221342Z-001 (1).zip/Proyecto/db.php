<?php
function conn(){
    $hostname= "localhost";
    $usuario= "root";
    $password= "";
    $dbname= "prueba";

    $conectar = mysqli_connect($hostname, $usuario, $password, $dbname);
    return $conectar;
}
?>
